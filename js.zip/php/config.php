<?php
// Arquivo de configuração com dados de conexão
$user = "dmarcian_admin"; 
$password = "O3Hl_!5u}.uU"; 
$database = "dmarcian_log_acessos"; 
$hostname = "localhost"; 
?>
